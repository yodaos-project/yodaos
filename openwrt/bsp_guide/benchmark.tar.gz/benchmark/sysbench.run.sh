#!/bin/bash
# cpu
echo "sysbench --test=cpu --num-threads=1 --cpu-max-prime=2000 --validate run"
sysbench --test=cpu --num-threads=1 --cpu-max-prime=2000 --validate run

echo "sysbench --test=cpu --num-threads=4 --cpu-max-prime=2000 --validate run"
sysbench --test=cpu --num-threads=4 --cpu-max-prime=2000 --validate run

# thread
echo "sysbench --test=threads --num-threads=64 --thread-yields=100 --thread-locks=2 run"
sysbench --test=threads --num-threads=64 --thread-yields=100 --thread-locks=2 run

#mutex
echo "sysbench --test=mutex --num-threads=16 --mutex-num=1024 --mutex-locks=10000 --mutex-loops=5000 run"
sysbench --test=mutex --num-threads=16 --mutex-num=1024 --mutex-locks=10000 --mutex-loops=5000 run

# memory
echo "sysbench --test=memory --num-threads=16 --memory-block-size=8192 --memory-total-size=1G run"
sysbench --test=memory --num-threads=16 --memory-block-size=8192 --memory-total-size=1G run

# file io
echo "sysbench --test=fileio --num-threads=16 --file-total-size=30M --file-test-mode=rndrw run"
sysbench --test=fileio --num-threads=16 --file-total-size=30M --file-test-mode=rndrw prepare
sysbench --test=fileio --num-threads=16 --file-total-size=30M --file-test-mode=rndrw run
sysbench --test=fileio --num-threads=16 --file-total-size=30M --file-test-mode=rndrw cleanup
